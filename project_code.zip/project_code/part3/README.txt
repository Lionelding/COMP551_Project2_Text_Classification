This is the implementation of part 3


To run the code:
	simply type "python part3.py" in the command line

The folder contains: 

1. train_in and train_out contains the 80000 data for training and validation
2. validate_in and validate_out contains 8000 data for testing 
3. test_in is the input for prediction
4. Summary is the cross-validation result
5. Output.csv is the prediction result
6. GoodSubmit is the formatted prediction result submitted on Kaggle 